
  
<h1 class="text-red-500 font-bold text-2xl">PushCart.Com</h1>
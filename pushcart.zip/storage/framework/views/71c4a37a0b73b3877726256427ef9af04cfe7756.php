<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Kerubin\Desktop\final project capstone\laravel breeze\Online-Shop\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>

  
<h1 class="text-red-500 font-bold text-2xl">PushCart.Com</h1><?php /**PATH C:\Users\Kerubin\Desktop\final project capstone\laravel breeze\Online-Shop\resources\views/components/application-logo.blade.php ENDPATH**/ ?>
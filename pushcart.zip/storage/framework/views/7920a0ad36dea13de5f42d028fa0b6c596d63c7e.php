<?php echo e($slot); ?>

<?php /**PATH C:\Users\Kerubin\Desktop\final project capstone\laravel breeze\Online-Shop\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
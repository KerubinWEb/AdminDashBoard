<footer class="flex-shrink-0 px-6 py-4">
    <p class="flex items-center justify-center gap-1 text-sm text-gray-600 dark:text-gray-400">
        <span>Shop Now!</span>
      
        <span>@</span>
        <a href="/" target="_blank" class="text-gray-600 hover:underline">
            PushCart.Com
        </a>
    </p>
</footer><?php /**PATH C:\Users\Kerubin\Desktop\final project capstone\laravel breeze\Online-Shop\resources\views/components/footer.blade.php ENDPATH**/ ?>